##  Struktura plików
* `index.html` – Struktura dokumentu
* `style.css` – Wygląd i układ (Flexbox)
* `skript.js` – Logika aplikacji i obsługa pamięci

##  Funkcje
* **Zarządzanie zadaniami:** Dodawanie nowych pozycji oraz usuwanie istniejących.
* **Zmiana statusu:** Przełączanie zadań między „do zrobienia” a „wykonane”.
* **Filtrowanie:** Widoki *Wszystkie*, *Do zrobienia* oraz *Wykonane*.
* **Dynamiczny licznik:** Informacja o postępie w formacie „X z Y wykonane”.
* **Zapis danych:** Pełna synchronizacja z `localStorage` – dane nie znikają po odświeżeniu strony.
