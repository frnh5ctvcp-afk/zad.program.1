var taskInput = document.getElementById('text-group'),
    addButton = document.getElementById('add-button'),
    todoList = document.getElementById('todo-list'),
    statusDisplay = document.getElementById('status'),
    filterButtons = document.querySelectorAll('.kolumny-btn'),
    currentFilter = 'all',
    todos = JSON.parse(localStorage.getItem('todos')) || [];

function render() {
    todoList.innerHTML = '';
    var completedCount = todos.filter(t => t.completed).length;

    todos.forEach(todo => {
        if (currentFilter === 'active' && todo.completed) return;
        if (currentFilter === 'completed' && !todo.completed) return;

        var li = document.createElement('li');
        li.className = 'todo-item' + (todo.completed ? ' completed' : '');
        li.innerHTML = `<div class="todo-item-left">
            <input type="checkbox" class="todo-checkbox" ${todo.completed ? 'checked' : ''} onchange="toggleStatus(${todo.id})">
            <span class="todo-text">${todo.text}</span>
        </div>
        <button type="button" class="btn-delete" onclick="deleteTodo(${todo.id})">Usuń</button>`;
        todoList.appendChild(li);
    });

    statusDisplay.textContent = `${completedCount} z ${todos.length} wykonane`;
    localStorage.setItem('todos', JSON.stringify(todos));
}

addButton.onclick = () => {
    if (!taskInput.value.trim()) return;
    todos.push({ id: Date.now(), text: taskInput.value, completed: false });
    taskInput.value = '';
    render();
};

var deleteTodo = id => { todos = todos.filter(t => t.id !== id); render(); };
var toggleStatus = id => { todos.map(t => t.id === id ? t.completed = !t.completed : t); render(); };

filterButtons.forEach(btn => btn.onclick = (e) => {
    filterButtons.forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');
    currentFilter = e.target.getAttribute('data-filter');
    render();
});

taskInput.onkeypress = e => { if (e.key === 'Enter') addButton.click(); };
render();
