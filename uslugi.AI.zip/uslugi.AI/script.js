
const formularz = document.querySelector("form");

formularz.addEventListener("submit", function(event) {
    event.preventDefault();

    const imie = document.querySelector("#imie").value;
    const email = document.querySelector("#email").value;
    const strona = document.querySelector("#strona").value;

    if (imie === "" || email === "" || strona === "") {
        alert("Wypełnij wszystkie pola!");
        return;
    }

    if (!email.includes("@") || !email.includes(".")) {
        alert("Podaj poprawny adres e-mail!");
        return;
    }

    alert("Dziękujemy! Formularz został wysłany.");

    formularz.reset();
});
