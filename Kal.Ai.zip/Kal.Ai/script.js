const selectPlan = document.getElementById('plan');
const inputPromty = document.getElementById('promty'); 
const checkPdf = document.getElementById('pdf');
const checkAnaliza = document.getElementById('analiza');
const radioMsc = document.getElementById('msc');
const radioRok = document.getElementById('rok');

const txtMiesieczny = document.getElementById('wynikMies');
const txtKoncowy = document.getElementById('wynikKon');
const txtOszczednosc = document.getElementById('oszczednosc');
const divOszczednosci = document.getElementById('sectionOszed');

function oblicz() {
    let cenaPlanu = Number(selectPlan.value);
    let pakiety = Number(inputPromty.value) || 0; 

    let cenaPdf = checkPdf.checked ? 19 : 0;
    let cenaAnaliza = checkAnaliza.checked ? 29 : 0;

    let sumaMiesieczna = cenaPlanu + (pakiety * 15) + cenaPdf + cenaAnaliza;
    
    txtMiesieczny.innerText = sumaMiesieczna.toFixed(2).replace('.', ',');

    if (radioRok.checked) {
        let cenaZaRok = sumaMiesieczna * 12;
        let rabat = cenaZaRok * 0.10; 
        let cenaKoncowa = cenaZaRok - rabat;
        txtKoncowy.innerText = cenaKoncowa.toFixed(2).replace('.', ',');
        txtOszczednosc.innerText = rabat.toFixed(2).replace('.', ',');
        divOszczednosci.style.display = 'block'; 
    } else {
        txtKoncowy.innerText = sumaMiesieczna.toFixed(2).replace('.', ',');
        divOszczednosci.style.display = 'none';  
    }
}
selectPlan.addEventListener('change', oblicz);
inputPromty.addEventListener('input', oblicz); 
checkPdf.addEventListener('change', oblicz);
checkAnaliza.addEventListener('change', oblicz);
radioMsc.addEventListener('change', oblicz);
radioRok.addEventListener('change', oblicz);

oblicz();
