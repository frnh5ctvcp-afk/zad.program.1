
##  Struktura plików
* `index.html` – Struktura formularza kalkulatora
* `style.css` – Stylowanie interfejsu
* `script.js` – Logika matematyczna i obsługa zdarzeń 

##  Funkcje
* **Wybór planu:** Dynamiczna cena bazowa w zależności od wybranego pakietu (*Starter*, *Pro*, *Business*).
* **Pakiety promtów:** Możliwość dokupienia dodatkowych pakietów w cenie +15 zł za każdy.
* **Opcje dodatkowe:** Przełączniki (checkboxy) dla raportu PDF (+19 zł) oraz analizy konkurencji (+29 zł).
* **Okres rozliczeniowy:** Wybór płatności miesięcznej lub rocznej z automatycznym naliczaniem **10% rabatu** i wyświetlaniem sekcji z oszczędnościami.
* **Dynamiczne obliczenia:** Wyniki (Suma miesięczna, Do zapłaty, Oszczędzasz) aktualizują się natychmiast po zmianie dowolnej opcji.